import numpy as np
import scipy.io.wavfile as wav
import sys

def calculate_snr(input_file, output_file):
    """
    Hàm tính toán độ SNR giữa hai tệp WAV (input và output).
    
    :param input_file: Tên tệp WAV gốc (input.wav)
    :param output_file: Tên tệp WAV đã chỉnh sửa (output.wav)
    :return: Độ SNR tính theo dB
    """
    # Đọc dữ liệu âm thanh từ tệp WAV
    sample_rate, original_signal = wav.read(input_file)
    _, modified_signal = wav.read(output_file)

    # Kiểm tra nếu tín hiệu có cùng số mẫu (số lượng mẫu phải khớp)
    if len(original_signal) != len(modified_signal):
        raise ValueError("Tín hiệu trong hai tệp WAV không có cùng số mẫu")

    # Tính năng lượng tín hiệu gốc (Signal Energy)
    signal_energy = np.sum(np.square(original_signal))

    # Tính năng lượng nhiễu (Noise Energy)
    noise_energy = np.sum(np.square(original_signal - modified_signal))

    # Kiểm tra nếu nhiễu bằng 0, tránh log10(0)
    if noise_energy == 0:
        print("Không có sự khác biệt giữa tín hiệu gốc và tín hiệu đã chỉnh sửa.")
        return np.inf  # Trả về vô cùng nếu không có nhiễu

    # Tính SNR
    snr = 10 * np.log10(signal_energy / noise_energy)
    
    return snr

# Ví dụ sử dụng:
input_file = sys.argv[1]  # Tên file âm thanh gốc
output_file = sys.argv[2]  # Tên file âm thanh đã giấu thông tin

snr_value = calculate_snr(input_file, output_file)
print(f"SNR: {snr_value:.2f} dB")

# Nhận xét về kết quả SNR:
if snr_value == np.inf:
    print("Thông báo: Không có sự khác biệt giữa tín hiệu gốc và tín hiệu đã chỉnh sửa. Điều này có thể xảy ra nếu bạn đã giấu thông tin mà không làm thay đổi đáng kể tín hiệu âm thanh.")
elif snr_value > 30:
    print("Kết quả SNR cho thấy chất lượng tín hiệu âm thanh rất tốt, không có nhiều thay đổi khi so sánh với tín hiệu gốc.")
elif snr_value > 20:
    print("Kết quả SNR cho thấy chất lượng tín hiệu âm thanh vẫn chấp nhận được với một số thay đổi nhỏ.")
elif snr_value > 10:
    print("Kết quả SNR cho thấy tín hiệu âm thanh đã thay đổi khá nhiều, có thể bắt đầu nhận thấy sự khác biệt.")
else:
    print("Kết quả SNR cho thấy tín hiệu âm thanh đã thay đổi đáng kể, có thể gây ra sự suy giảm chất lượng âm thanh rõ rệt.")

