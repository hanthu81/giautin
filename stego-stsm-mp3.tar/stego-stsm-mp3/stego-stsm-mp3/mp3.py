from pydub import AudioSegment
import os
import sys

sound = AudioSegment.from_wav(sys.argv[1])

# Xuất ra file MP3
sound.export("stego.mp3", format="mp3", bitrate="64k")

print("Chuyển đổi hoàn tất!")


