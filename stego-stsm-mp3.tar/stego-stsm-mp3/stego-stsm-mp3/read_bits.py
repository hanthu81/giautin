# read_bit_count.py
import numpy as np
import scipy.io.wavfile as wav
import sys

def two_samples_to_int(samples):
    high = samples[0] & 0xFF
    low = samples[1] & 0xFF
    return (high << 8) + low

def read_bit_count(stego_audio_file):
    rate, data = wav.read(stego_audio_file)
    if data.ndim > 1:
        data = data[:, 0]
    data = data.astype(np.int16)
    return two_samples_to_int(data[0:2])

if __name__ == "__main__":

    input_file = sys.argv[1]
    output_file = "bit_count.txt"

    bit_count = read_bit_count(input_file)

    with open(output_file, "w") as f:
        f.write(str(bit_count))

    print(f"✅ Đã lưu số bit {bit_count} vào {output_file}")

