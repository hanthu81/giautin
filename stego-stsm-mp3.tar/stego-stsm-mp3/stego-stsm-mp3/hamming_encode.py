import numpy as np

# Hàm mã hóa Hamming (7,4)
def hamming_encode_4bits(data4):
    G = np.array([
        [1, 0, 0, 0, 1, 1, 0],
        [0, 1, 0, 0, 1, 0, 1],
        [0, 0, 1, 0, 0, 1, 1],
        [0, 0, 0, 1, 1, 1, 1]
    ])
    return np.dot(data4, G) % 2

# Chuyển chuỗi thành danh sách bit
def string_to_bitlist(s):
    return [int(bit) for char in s.encode('utf-8') for bit in format(char, '08b')]

# Mã hóa toàn bộ chuỗi bit
def encode_message_hamming(msg_bits):
    chunks = [msg_bits[i:i+4] for i in range(0, len(msg_bits), 4)]
    encoded_bits = []
    for chunk in chunks:
        if len(chunk) < 4:
            chunk += [0] * (4 - len(chunk))  # Đệm thêm 0 nếu chưa đủ 4 bit
        encoded = hamming_encode_4bits(np.array(chunk))
        encoded_bits.extend(encoded)
    return encoded_bits

# Ghi danh sách bit ra file
def write_bits_to_file(bits, output_file):
    with open(output_file, 'w') as f:
        f.write(''.join(str(b) for b in bits))

def main():
    input_file = 'message.txt'  # File chứa thông điệp
    output_file = 'hamming_encoded.txt'  # File chứa kết quả

    with open(input_file, 'r', encoding='utf-8') as f:
        secret = f.read().strip()

    secret_bits = string_to_bitlist(secret)
    encoded_bits = encode_message_hamming(secret_bits)

    print(f"[+] Chuỗi gốc: {secret}")
    print(f"[+] Số bit sau mã hóa Hamming: {len(encoded_bits)}")
    write_bits_to_file(encoded_bits, output_file)
    print(f"[+] Đã lưu mã Hamming vào: {output_file}")

if __name__ == '__main__':
    main()

