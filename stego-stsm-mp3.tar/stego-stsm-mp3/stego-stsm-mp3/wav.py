from pydub import AudioSegment
import sys
# Đọc tệp MP3
mp3_file = sys.argv[1]
audio = AudioSegment.from_mp3(mp3_file)

# Lưu lại dưới định dạng WAV
audio.export("output.wav", format="wav")

