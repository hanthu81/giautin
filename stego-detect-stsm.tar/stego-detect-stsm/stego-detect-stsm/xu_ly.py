import librosa
import numpy as np

# Hàm trích xuất các đặc trưng từ file âm thanh
def extract_features(file_path):
    # Tải file âm thanh
    y, sr = librosa.load(file_path)

    # Trích xuất Spectral Centroid
    spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))

    # Trích xuất Spectral Roll-off
    


    # Trích xuất Zero-Crossing Rate
    zero_crossing_rate = np.mean(librosa.feature.zero_crossing_rate(y))

    # Trích xuất MFCC (Mel-Frequency Cepstral Coefficients)
    mfcc = np.mean(librosa.feature.mfcc(y=y, sr=sr), axis=1)

    # Trích xuất Spectral Flux
    spectral_flux = np.mean(librosa.onset.onset_strength(y=y, sr=sr))

    # Tạo dictionary lưu các đặc trưng
    features = {
        'spectral_centroid': spectral_centroid,
        'zero_crossing_rate': zero_crossing_rate,
        'mfcc': mfcc,
        'spectral_flux': spectral_flux
    }
    
    return features

# Hàm so sánh các đặc trưng giữa hai file âm thanh
def compare_features(file1_features, file2_features):
    comparison = {}

    # So sánh các đặc trưng
    for key in file1_features.keys():
        if isinstance(file1_features[key], np.ndarray):
            # Nếu là MFCC (vì MFCC là một vector), so sánh từng giá trị
            comparison[key] = np.linalg.norm(file1_features[key] - file2_features[key])
        else:
            # Nếu là các đặc trưng số (spectral_centroid, spectral_rolloff...), so sánh trực tiếp
            comparison[key] = abs(file1_features[key] - file2_features[key])

    return comparison

# Tải và trích xuất đặc trưng từ hai file âm thanh
input_features = extract_features('input.wav')
output_features = extract_features('output_with_hidden_data.wav')

# So sánh các đặc trưng giữa hai file
comparison_results = compare_features(input_features, output_features)

# In kết quả so sánh
print("Kết quả so sánh các đặc trưng:")
for feature, value in comparison_results.items():
    print(f"{feature}: {value}")

