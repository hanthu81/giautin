import numpy as np
import scipy.io.wavfile as wav
import matplotlib.pyplot as plt
# Phân tích tần số (FFT) của tín hiệu
def read_wav(filename):
    rate, data = wav.read(filename)
    
    # Nếu là stereo, chuyển sang mono
    if data.ndim == 2:
        data = data.mean(axis=1).astype(np.int16)
    
    return rate, data
def analyze_frequency(signal, rate):
    # Sử dụng FFT để phân tích tín hiệu
    fft_signal = np.fft.fft(signal)
    fft_freq = np.fft.fftfreq(len(fft_signal), 1 / rate)
    
    # Lấy phần thực và phần ảo của FFT
    magnitude = np.abs(fft_signal)
    phase = np.angle(fft_signal)
    
    # Trả về tần số và biên độ FFT
    return fft_freq, magnitude

# Ví dụ sử dụng phân tích tần số
def extract_features_frequency(signal, rate):
    fft_freq, magnitude = analyze_frequency(signal, rate)
    
    # Lấy các đặc trưng từ phổ tần số
    max_magnitude = np.max(magnitude)
    min_magnitude = np.min(magnitude)
    mean_magnitude = np.mean(magnitude)
    
    return max_magnitude, min_magnitude, mean_magnitude

# Sử dụng để trích xuất đặc trưng tần số
rate1, signal1 = read_wav('input.wav')
rate2, signal2 = read_wav('output_with_hidden_data.wav')

max_magnitude1, min_magnitude1, mean_magnitude1 = extract_features_frequency(signal1, rate1)
max_magnitude2, min_magnitude2, mean_magnitude2 = extract_features_frequency(signal2, rate2)

print(f"Tín hiệu input - Max Magnitude: {max_magnitude1}, Min Magnitude: {min_magnitude1}, Mean Magnitude: {mean_magnitude1}")
print(f"Tín hiệu output - Max Magnitude: {max_magnitude2}, Min Magnitude: {min_magnitude2}, Mean Magnitude: {mean_magnitude2}")

