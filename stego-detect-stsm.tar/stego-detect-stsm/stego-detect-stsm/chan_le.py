import numpy as np
import scipy.io.wavfile as wav

# Đọc tín hiệu âm thanh từ file WAV
def read_wav(filename):
    rate, data = wav.read(filename)
    
    # Nếu là stereo, chuyển sang mono
    if data.ndim == 2:
        data = data.mean(axis=1).astype(np.int16)
    
    return rate, data


# Đếm số nhóm 3 mẫu có tổng chẵn hoặc lẻ
def count_parity_triplets(signal):
    odd_count = 0
    even_count = 0
    for i in range(0, len(signal)-2, 3):
        triplet = signal[i:i+3]
        if len(triplet) < 3:
            continue
        total = np.sum(triplet)
        if total % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    return even_count, odd_count

# Đọc tín hiệu từ hai file âm thanh
rate1, signal1 = read_wav('input.wav')
rate2, signal2 = read_wav('output_with_hidden_data.wav')

# Kiểm tra xem tần số lấy mẫu có giống nhau không
if rate1 != rate2:
    print("Tần số lấy mẫu của hai file khác nhau!")
else:
    print("Tần số lấy mẫu giống nhau:", rate1)

    # Đếm số nhóm 3 mẫu cho cả hai tín hiệu
    even1, odd1 = count_parity_triplets(signal1)
    even2, odd2 = count_parity_triplets(signal2)

    # Tổng số nhóm 3 mẫu
    total1 = even1 + odd1
    total2 = even2 + odd2

    print(f"Tín hiệu input - Tổng số nhóm 3 mẫu: {total1}")
    print(f"Tín hiệu input - Tỉ lệ tổng chẵn: {even1/total1:.2f}, tổng lẻ: {odd1/total1:.2f}")

    print(f"Tín hiệu output - Tổng số nhóm 3 mẫu: {total2}")
    print(f"Tín hiệu output - Tỉ lệ tổng chẵn: {even2/total2:.2f}, tổng lẻ: {odd2/total2:.2f}")

