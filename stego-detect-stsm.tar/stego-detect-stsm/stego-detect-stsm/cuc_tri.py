import numpy as np
import scipy.io.wavfile as wav
import matplotlib.pyplot as plt
from scipy.signal import argrelextrema

# Đọc tín hiệu âm thanh từ file WAV
def read_wav(filename):
    rate, data = wav.read(filename)
    if data.ndim == 2:
        data = data.mean(axis=1).astype(np.int16)
    return rate, data

# Tìm local extrema
def find_extrema(signal, order=5):
    maxima = argrelextrema(signal, np.greater, order=order)[0]
    minima = argrelextrema(signal, np.less, order=order)[0]
    return maxima, minima

# Tính độ dốc giữa cực đại - cực tiểu
def analyze_slopes(signal, maxima, minima, N=5):
    slopes = []
    pairs = zip(maxima, minima) if len(maxima) <= len(minima) else zip(minima, maxima)
    for i, j in pairs:
        if abs(i - j) < N:
            continue
        segment = np.linspace(signal[i], signal[j], N+1)
        segment_slopes = np.diff(segment)
        slopes.extend(segment_slopes)
    return slopes

# So sánh cực trị giữa hai tín hiệu
def compare_extrema(max1, min1, max2, min2, signal1, signal2):
    print(f"Số lượng cực đại - input: {len(max1)}, output: {len(max2)}")
    print(f"Số lượng cực tiểu - input: {len(min1)}, output: {len(min2)}")

    # So sánh vị trí cực đại
    max_diff_positions = np.abs(max1[:min(len(max1), len(max2))] - max2[:min(len(max1), len(max2))])
    max_diff_values = np.abs(signal1[max1[:len(max_diff_positions)]] - signal2[max2[:len(max_diff_positions)]])
    print("Chênh lệch vị trí cực đại:", np.mean(max_diff_positions))
    print("Chênh lệch giá trị cực đại:", np.mean(max_diff_values))

    # So sánh vị trí cực tiểu
    min_diff_positions = np.abs(min1[:min(len(min1), len(min2))] - min2[:min(len(min1), len(min2))])
    min_diff_values = np.abs(signal1[min1[:len(min_diff_positions)]] - signal2[min2[:len(min_diff_positions)]])
    print("Chênh lệch vị trí cực tiểu:", np.mean(min_diff_positions))
    print("Chênh lệch giá trị cực tiểu:", np.mean(min_diff_values))

# Đọc hai file âm thanh
rate1, signal1 = read_wav('input.wav')
rate2, signal2 = read_wav('output_with_hidden_data.wav')

# Kiểm tra xem tần số lấy mẫu có giống nhau không
if rate1 != rate2:
    print("Tần số lấy mẫu của hai file khác nhau!")
else:
    print("Tần số lấy mẫu giống nhau:", rate1)

    # Tìm cực trị và phân tích độ dốc cho cả hai tín hiệu
    maxima1, minima1 = find_extrema(signal1)
    maxima2, minima2 = find_extrema(signal2)

    slopes1 = analyze_slopes(signal1, maxima1, minima1)
    slopes2 = analyze_slopes(signal2, maxima2, minima2)

    # So sánh cực trị
    compare_extrema(maxima1, minima1, maxima2, minima2, signal1, signal2)

