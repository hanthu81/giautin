import numpy as np
import scipy.io.wavfile as wav
import matplotlib.pyplot as plt

# Đọc WAV và chuyển về mono
def read_wav(filename):
    rate, data = wav.read(filename)
    if data.ndim == 2:
        data = data.mean(axis=1)
    return rate, data

# Hàm chuẩn hóa và loại bỏ DC offset
def preprocess_signal(signal):
    signal = signal - np.mean(signal)  # bỏ DC offset
    signal = signal / np.max(np.abs(signal))  # chuẩn hóa [-1, 1]
    return signal

# Tính phổ biên độ
def compute_magnitude_spectrum(signal):
    fft = np.fft.fft(signal)
    mag = np.abs(fft)
    return mag[:len(mag)//2]  # chỉ lấy nửa phổ

# Đọc 2 file
rate1, sig1 = read_wav('input.wav')
rate2, sig2 = read_wav('output_with_hidden_data.wav')

# Kiểm tra tần số lấy mẫu
if rate1 != rate2:
    print("⚠️ Hai file có tần số lấy mẫu khác nhau!")
else:
    print(f"Tần số lấy mẫu giống nhau: {rate1}")

# Xử lý tín hiệu
sig1 = preprocess_signal(sig1)
sig2 = preprocess_signal(sig2)

# Tính phổ
mag1 = compute_magnitude_spectrum(sig1)
mag2 = compute_magnitude_spectrum(sig2)

# Vẽ phổ log-scale
plt.figure(figsize=(12, 5))
plt.plot(20 * np.log10(mag1 + 1e-10), label='Input (Original)')
plt.plot(20 * np.log10(mag2 + 1e-10), label='Output (Hidden data)', alpha=0.7)
plt.title("So sánh phổ biên độ tín hiệu (log scale)")
plt.xlabel("Tần số (bin)")
plt.ylabel("Biên độ (dB)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("log_scale_plot.png")
print("Đã lưu đồ thị dưới dạng log_scale_plot.png")
rmse = np.sqrt(np.mean((20 * np.log10(mag1 + 1e-10) - 20 * np.log10(mag2 + 1e-10))**2))
print(f"RMSE giữa 2 phổ log-scale: {rmse:.4f} dB")
