# find_extrema.py
import numpy as np
import scipy.io.wavfile as wav
from scipy.signal import argrelextrema

def find_extrema(signal):
    max_idx = argrelextrema(signal, np.greater)[0]
    min_idx = argrelextrema(signal, np.less)[0]
    extrema = np.sort(np.concatenate((max_idx, min_idx)))
    return extrema

def get_signal_from_wav(file_path):
    rate, data = wav.read(file_path)
    if data.ndim > 1:
        data = data[:, 0]
    return data.astype(np.int16)

if __name__ == "__main__":
    input_file = "output_with_hidden_data.wav"
    output_file = "extrema.npy"  # Dùng phần mở rộng đúng

    signal = get_signal_from_wav(input_file)
    extrema = find_extrema(signal)

    # In ra màn hình
    print("📍 Danh sách chỉ số cực trị:")
    print(extrema)

    # Lưu mảng cực trị
    np.save(output_file, extrema)

    print(f"✅ Đã lưu {len(extrema)} chỉ số cực trị vào {output_file}")

