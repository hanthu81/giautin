# extract_bits.py
import numpy as np
import scipy.io.wavfile as wav
import sys

def get_signal_from_wav(file_path):
    rate, data = wav.read(file_path)
    if data.ndim > 1:
        data = data[:, 0]
    return data.astype(np.int16)

def extract_bit_from_segment(signal, start):
    if start + 3 > len(signal):
        return None
    segment = signal[start:start+3]
    total = int(np.sum(segment))
    return 1 if total % 2 != 0 else 0

def extract_message(bit_count_file, extrema_file):
    audio_file = "output_with_hidden_data.wav"
    output_bit_file = "extracted_bit.txt"
    signal = get_signal_from_wav(audio_file)

    with open(bit_count_file, "r") as f:
        bit_count = int(f.read().strip())

    extrema = np.load(extrema_file)

    if len(extrema) < bit_count:
        raise ValueError("Không đủ cực trị để tách toàn bộ bit")

    extracted_bits = []
    for i in range(bit_count):
        start = extrema[i]
        bit = extract_bit_from_segment(signal, start)
        if bit is not None:
            extracted_bits.append(str(bit))

    with open(output_bit_file, 'w') as f:
        f.write(''.join(extracted_bits))

    print(f"✅ Đã tách {bit_count} bit và lưu vào {output_bit_file}")

if __name__ == "__main__":
    extract_message(sys.argv[1], sys.argv[2])

