import numpy as np

# Hàm giải mã Hamming (7,4) và sửa lỗi nếu có
def hamming_decode_7bits(code7):
    H = np.array([
        [1, 1, 0, 1, 1, 0, 0],
        [1, 0, 1, 1, 0, 1, 0],
        [0, 1, 1, 1, 0, 0, 1]
    ])

    # Tính syndrome (kiểm tra lỗi)
    syndrome = np.dot(H, code7.T) % 2
    syndrome_decimal = int(''.join(str(bit) for bit in syndrome[::-1]), 2)

    if syndrome_decimal != 0:
        print(f"[!] Phát hiện lỗi tại bit thứ {syndrome_decimal}, sửa lỗi.")
        # Sửa lỗi tại vị trí phát hiện (đảo bit)
        code7[syndrome_decimal - 1] ^= 1  # Đảo bit bị lỗi

    # Trích xuất 4 bit dữ liệu (các bit 1-4 trong G tương ứng vị trí 0,1,2,3)
    data_bits = [code7[0], code7[1], code7[2], code7[3]]
    return data_bits

# Hàm đọc bits từ file
def read_bits_from_file(file_path):
    with open(file_path, 'r') as f:
        bit_string = f.read().strip()
    return [int(b) for b in bit_string]

# Hàm giải mã toàn bộ thông điệp
def decode_hamming_message(encoded_bits):
    chunks = [encoded_bits[i:i+7] for i in range(0, len(encoded_bits), 7)]
    decoded_bits = []
    for chunk in chunks:
        if len(chunk) < 7:
            chunk += [0] * (7 - len(chunk))  # Đệm nếu thiếu bit
        decoded = hamming_decode_7bits(np.array(chunk))
        decoded_bits.extend(decoded)
    return decoded_bits

# Chuyển danh sách bit thành chuỗi ký tự
def bitlist_to_string(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            byte += [0] * (8 - len(byte))  # Đệm nếu thiếu bit
        chars.append(chr(int(''.join(str(b) for b in byte), 2)))
    return ''.join(chars)

# Ghi thông điệp đã giải mã vào file
def write_decoded_message_to_file(decoded_message, output_file):
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(decoded_message)

def main():
    input_file = 'extracted_bit.txt'  # File chứa dữ liệu mã hóa Hamming
    output_file = 'decoded_secret.txt'  # File lưu thông điệp giải mã

    # Đọc dữ liệu mã hóa từ file input
    encoded_bits = read_bits_from_file(input_file)

    # Giải mã dữ liệu
    decoded_bits = decode_hamming_message(encoded_bits)
    decoded_message = bitlist_to_string(decoded_bits)

    # Ghi thông điệp giải mã vào file output
    write_decoded_message_to_file(decoded_message, output_file)
    print(f"[+] Đã lưu thông điệp vào: {output_file}")

if __name__ == '__main__':
    main()

