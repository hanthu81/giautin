import pywt
import numpy as np
import scipy.io.wavfile as wav
# Áp dụng biến đổi Wavelet lên tín hiệu âm thanh

def apply_wavelet(input_file, output_file):
    rate, data = wav.read(input_file)
    coeffs = pywt.wavedec(data, 'db1', level=1)
    data_reconstructed = pywt.waverec(coeffs, 'db1')
    wav.write(output_file, rate, data_reconstructed.astype(np.int16))
    print(f'✅ Đã áp dụng DWT và lưu vào {output_file}')
apply_wavelet("input.wav", "input2.wav")
