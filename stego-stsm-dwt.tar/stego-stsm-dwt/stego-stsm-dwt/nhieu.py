import numpy as np
import sys
import scipy.io.wavfile as wav

def add_noise(signal, snr_db):
    """
    Thêm nhiễu trắng (Gaussian) vào tín hiệu với SNR chỉ định.
    """
    signal_power = np.mean(signal ** 2)
    snr_linear = 10 ** (snr_db / 10)
    noise_power = signal_power / snr_linear

    noise = np.random.normal(0, np.sqrt(noise_power), signal.shape)
    noisy_signal = signal + noise
    return noisy_signal.astype(np.int16)

# Đọc file đã giấu tin
rate, data = wav.read(sys.argv[1])
if data.ndim > 1:
    data = data[:, 0]  # chuyển stereo về mono

# Thêm nhiễu
snr_db = 30  # SNR = 30 dB
noisy_data = add_noise(data, snr_db)

# Ghi ra file mới
wav.write("output_noisy.wav", rate, noisy_data)
print("✅ Đã thêm nhiễu và lưu vào output_noisy.wav")

