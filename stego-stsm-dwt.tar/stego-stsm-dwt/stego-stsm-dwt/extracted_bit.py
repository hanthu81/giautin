import sys
def binary_file_to_string(file_path):
    try:
        with open(file_path, 'r') as file:
            # Đọc toàn bộ dữ liệu nhị phân từ file
            binary_data = file.read().replace('\n', '')  # Loại bỏ xuống dòng
        # Chia thành các nhóm 8 bit và chuyển đổi
        bytes_list = [binary_data[i:i+8] for i in range(0, len(binary_data), 8)]
        char_list = [chr(int(byte, 2)) for byte in bytes_list]
        return ''.join(char_list)
    except Exception as e:
        return f"Lỗi: {e}"

# Ví dụ sử dụng
file_path = sys.argv[1]
result = binary_file_to_string(file_path)
print("Chuỗi ký tự là:", result)

