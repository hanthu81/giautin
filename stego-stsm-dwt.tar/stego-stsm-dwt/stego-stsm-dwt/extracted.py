import numpy as np
import scipy.io.wavfile as wav
import sys
from scipy.signal import argrelextrema

def two_samples_to_int(samples):
    """
    Chuyển 2 mẫu 16-bit thành số nguyên đại diện số bit đã nhúng
    """
    high = samples[0] & 0xFF
    low = samples[1] & 0xFF
    return (high << 8) + low

def find_extrema(signal):
    max_idx = argrelextrema(signal, np.greater)[0]
    min_idx = argrelextrema(signal, np.less)[0]
    extrema = np.sort(np.concatenate((max_idx, min_idx)))
    return extrema

def extract_bit_from_segment(signal, start):
    """
    Đọc 3 mẫu từ vị trí start, tính tổng và xác định bit
    """
    if start + 3 > len(signal):
        return None  # Không đủ mẫu
    segment = signal[start:start+3]
    total = int(np.sum(segment))
    return 1 if total % 2 != 0 else 0

def extract_message(output_bit_file,stego_audio_file):
    # Đọc file âm thanh đã giấu tin
    bit_count_file="bit_count.txt"
    with open(bit_count_file, 'r') as f:
        bit_count = int(f.read().strip())
    rate, data = wav.read(stego_audio_file)
    if data.ndim > 1:
        data = data[:, 0]  # Lấy 1 kênh nếu stereo
    data = data.astype(np.int16)

    # Tìm lại các cực trị như lúc nhúng
    extrema = find_extrema(data)
    if len(extrema) < bit_count:
        raise ValueError("Không đủ cực trị để tách toàn bộ bit")

    # Giải mã bit
    extracted_bits = []
    for i in range(bit_count):
        start = extrema[i]
        bit = extract_bit_from_segment(data, start)
        if bit is not None:
            extracted_bits.append(str(bit))

    # Ghi các bit ra file
    with open(output_bit_file, 'w') as f:
        f.write(''.join(extracted_bits))

    print(f"✅ Đã giải mã và lưu vào {output_bit_file}")
extract_message(sys.argv[1],sys.argv[2])

