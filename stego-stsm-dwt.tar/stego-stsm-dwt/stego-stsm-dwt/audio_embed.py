import numpy as np
import scipy.io.wavfile as wav
from scipy.signal import argrelextrema

def read_encoded_bits(file_path):
    with open(file_path, 'r') as f:
        data = f.read().strip()
    return [int(b) for b in data]

def find_extrema(signal):
    max_idx = argrelextrema(signal, np.greater)[0]
    min_idx = argrelextrema(signal, np.less)[0]
    extrema = np.sort(np.concatenate((max_idx, min_idx)))
    return extrema

def embed_bit_between_extrema(signal, start, bit):
    """
    Nhúng bit vào 3 mẫu liên tiếp từ vị trí start
    bằng cách chỉnh tổng 3 mẫu sao cho:
        - Tổng lẻ → bit = 1
        - Tổng chẵn → bit = 0
    """
    if start + 3 > len(signal):
        return signal  # Không đủ 3 mẫu

    segment = signal[start:start+3].copy()
    total = int(np.sum(segment))

    if bit == 1 and total % 2 == 0:
        # Tổng đang chẵn, cần làm lẻ
        if abs(segment[1]) < 32767:
            segment[1] += 1
    elif bit == 0 and total % 2 != 0:
        # Tổng đang lẻ, cần làm chẵn
        if abs(segment[1]) < 32767:
            segment[1] += 1

    signal[start:start+3] = segment
    return signal

def int_to_two_samples(value):
    """
    Chuyển số nguyên thành 2 mẫu 16-bit để lưu vào âm thanh.
    Giới hạn tối đa là 65535 bit (2 byte)
    """
    high = (value >> 8) & 0xFF
    low = value & 0xFF
    return np.array([high, low], dtype=np.int16)

def embed_message(audio_file, bit_file, output_file):
    rate, data = wav.read(audio_file)
    if data.ndim > 1:
        data = data[:, 0]
    data = data.astype(np.int16)

    encoded_bits = read_encoded_bits(bit_file)
    bit_count = len(encoded_bits)

    if bit_count > 65535:
        raise ValueError("Quá nhiều bit cần giấu (>65535)")
    data[0:2] = int_to_two_samples(bit_count)

    extrema = find_extrema(data)
    if len(extrema) < bit_count:
        raise ValueError("Không đủ cực trị để nhúng toàn bộ bit")

    for i in range(bit_count):
        data = embed_bit_between_extrema(data, extrema[i], encoded_bits[i])

    wav.write(output_file, rate, data)
    print(f"✅ Đã giấu {bit_count} bit vào {output_file}")

embed_message("input.wav", "bits.txt", "output.wav")

