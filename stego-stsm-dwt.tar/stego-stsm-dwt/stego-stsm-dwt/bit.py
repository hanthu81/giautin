def file_to_bits(file_path):
    with open(file_path, 'rb') as f:
        byte_data = f.read()
    bits = ''.join(f'{byte:08b}' for byte in byte_data)
    return bits

def save_bits_to_file(bit_string, output_path):
    with open(output_path, 'w') as f:
        f.write(bit_string)

# Ví dụ sử dụng
input_file = 'message.txt'         # Tệp đầu vào
output_file = 'bits.txt'    # Tệp đầu ra
bit_string = file_to_bits(input_file)
save_bits_to_file(bit_string, output_file)

print(f"Đã lưu {len(bit_string)} bit vào '{output_file}'\t")
print("Bit:", bit_string)
print("Tổng số bit:", len(bit_string))

