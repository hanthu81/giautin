import sys
# Hàm tính độ chính xác
def calculate_accuracy(original_bits, extracted_bits):
    correct_count = sum(1 for ob, eb in zip(original_bits, extracted_bits) if ob == eb)
    accuracy = correct_count / len(original_bits) * 100
    return accuracy

# Đọc bit gốc từ file
with open("bits.txt", "r") as f:
    original_bits = list(f.read().strip())

# Đọc bit tách ra từ file
with open(sys.argv[1], "r") as f:
    extracted_bits = list(f.read().strip())

# Tính độ chính xác
accuracy = calculate_accuracy(original_bits, extracted_bits)

# In kết quả
print(f"Độ chính xác: {accuracy:.2f}%")

